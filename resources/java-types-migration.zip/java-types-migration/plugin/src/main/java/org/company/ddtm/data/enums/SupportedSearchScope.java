package org.company.ddtm.data.enums;

public enum SupportedSearchScope {
    LOCAL, FILE, PROJECT
}
