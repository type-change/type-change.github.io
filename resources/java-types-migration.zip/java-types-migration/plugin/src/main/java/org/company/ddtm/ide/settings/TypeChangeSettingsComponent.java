package org.company.ddtm.ide.settings;

import com.intellij.openapi.ui.ComboBox;
import com.intellij.ui.JBIntSpinner;
import com.intellij.ui.components.JBLabel;
import com.intellij.ui.components.JBTextArea;
import com.intellij.util.ui.FormBuilder;
import org.company.ddtm.Config;
import org.company.ddtm.DataDrivenTypeMigrationBundle;
import org.company.ddtm.data.TypeChangeRulesProvider;
import org.company.ddtm.data.enums.SupportedSearchScope;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

public class TypeChangeSettingsComponent {
    private final JPanel panel;
    private final JBIntSpinner disableIntentionTimeoutIntSpinner =
            new JBIntSpinner(Config.DISABLE_INTENTION_TIMEOUT_BY_DEFAULT, 1_000, 100_000, 1_000);
    private final ComboBox<String> searchScopeOptionsComboBox =
            new ComboBox<>(DataDrivenTypeMigrationBundle.SEARCH_SCOPE_OPTIONS.values().toArray(String[]::new));
    private final JBTextArea typeChangeRulesEditor =
            new JBTextArea(TypeChangeRulesProvider.getInstance().getStateJson(), 100, 200);

    public TypeChangeSettingsComponent() {
        panel = FormBuilder.createFormBuilder()
                .addLabeledComponent(
                        new JBLabel(DataDrivenTypeMigrationBundle.message("settings.timeout.spinner.label")),
                        disableIntentionTimeoutIntSpinner,
                        1,
                        false
                )
                .addLabeledComponent(
                        new JBLabel(DataDrivenTypeMigrationBundle.message("settings.scope.combobox.label")),
                        searchScopeOptionsComboBox,
                        1,
                        false
                )
                .addLabeledComponent(
                        new JBLabel(DataDrivenTypeMigrationBundle.message("settings.rules.source")),
                        typeChangeRulesEditor,
                        1,
                        true
                )
                .addComponentFillVertically(new JPanel(), 0)
                .getPanel();
    }

    public JPanel getPanel() {
        return panel;
    }

    public JComponent getPreferredFocusedComponent() {
        return searchScopeOptionsComboBox;
    }

    public SupportedSearchScope getSearchScopeOption() {
        return DataDrivenTypeMigrationBundle.SEARCH_SCOPE_OPTIONS.inverse().get(searchScopeOptionsComboBox.getSelectedItem());
    }

    public void setSearchScopeOption(@NotNull SupportedSearchScope searchScope) {
        searchScopeOptionsComboBox.setSelectedItem(DataDrivenTypeMigrationBundle.SEARCH_SCOPE_OPTIONS.get(searchScope));
    }

    public int getDisableIntentionTimeout() {
        return disableIntentionTimeoutIntSpinner.getNumber();
    }

    public void setDisableIntentionTimeout(int timeout) {
        disableIntentionTimeoutIntSpinner.setNumber(timeout);
    }

    public String getEditorJson() {
        return typeChangeRulesEditor.getText();
    }

    public void setEditorJson(String json) {
        typeChangeRulesEditor.setText(json);
    }
}