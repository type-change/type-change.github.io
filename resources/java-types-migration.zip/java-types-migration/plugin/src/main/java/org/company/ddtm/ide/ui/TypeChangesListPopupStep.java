package org.company.ddtm.ide.ui;

import com.intellij.openapi.progress.ProgressManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.popup.PopupStep;
import com.intellij.openapi.ui.popup.util.BaseListPopupStep;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiType;
import org.company.ddtm.DataDrivenTypeMigrationBundle;
import org.company.ddtm.data.enums.InvocationWorkflow;
import org.company.ddtm.data.models.TypeChangePatternDescriptor;
import org.company.ddtm.ide.migration.TypeChangeProcessor;
import org.company.ddtm.utils.PsiRelatedUtils;
import org.company.ddtm.utils.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class TypeChangesListPopupStep extends BaseListPopupStep<TypeChangePatternDescriptor> {
    private final InvocationWorkflow invocationWorkflow;
    private final Project project;
    private final PsiElement context;
    private final PsiType sourceType;
    private TypeChangePatternDescriptor selectedPatternDescriptor = null;

    public TypeChangesListPopupStep(String caption,
                                    List<TypeChangePatternDescriptor> rulesDescriptors,
                                    PsiElement context,
                                    Project project,
                                    InvocationWorkflow invocationWorkflow) {
        super(caption, rulesDescriptors.stream()
                .sorted(Comparator.comparing(TypeChangePatternDescriptor::getRank).reversed())
                .collect(Collectors.toList())
        );
        this.sourceType = Objects.requireNonNull(PsiRelatedUtils.getClosestPsiTypeElement(context)).getType();
        this.context = context;
        this.project = project;
        this.invocationWorkflow = invocationWorkflow;
    }

    @Override
    public @Nullable PopupStep<?> onChosen(TypeChangePatternDescriptor selectedValue, boolean finalChoice) {
        selectedPatternDescriptor = selectedValue;
        return super.onChosen(selectedValue, finalChoice);
    }

    @Override
    public @NotNull String getTextFor(TypeChangePatternDescriptor value) {
        return DataDrivenTypeMigrationBundle.message(
                "intention.list.item.text",
                StringUtils.escapeSSRTemplates(value.resolveTargetType(sourceType, project))
        );
    }

    @Override
    public @Nullable Runnable getFinalRunnable() {
        return () -> {
            final var processor = new TypeChangeProcessor(project, invocationWorkflow);
            ProgressManager.getInstance().runProcessWithProgressSynchronously(() -> {
                ProgressManager.getInstance().getProgressIndicator().setIndeterminate(true);
                processor.run(context, selectedPatternDescriptor);
            }, DataDrivenTypeMigrationBundle.message("intention.family.name"), true, project);
        };
    }
}
