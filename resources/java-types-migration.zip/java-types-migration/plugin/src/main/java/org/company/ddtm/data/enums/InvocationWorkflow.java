package org.company.ddtm.data.enums;

public enum InvocationWorkflow {
    PROACTIVE, REACTIVE, INSPECTING
}
