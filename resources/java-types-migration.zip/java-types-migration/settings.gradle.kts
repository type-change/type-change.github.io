rootProject.name = "data-driven-type-migration"
include("evaluation")
include("plugin")
